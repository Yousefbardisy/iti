function getCookie(cookieName) {
  result = getAllCookieList();
  for (var key in result) {
    if (cookieName === key) {
      return result[key];
    }
  }
}
function setCookie(cookieName, cookieValue, expiryDate) {
  document.cookie = ""+cookieName+"="+cookieValue+";expires="+expiryDate+";"

}
function deleteCookie(cookieName) {
  var cookies = getAllCookieList();
  for (var key in cookies) {
    if (cookieName === key) {
      
      document.cookie = key + "=  ;expires=10-10-2020";
    }
  }
}
function getAllCookieList() {
  var assoiativeCookie = [];
  var splitCookie = document.cookie.split(";");
  for (var index = 0; index < splitCookie.length; index++) {
    assoiativeCookie[splitCookie[index].split("=")[0].trim()] = splitCookie[
      index
    ].split("=")[1];
  }
  return assoiativeCookie;
}

function checkCookie(cookieName) {
  var cookies = getAllCookieList();
  for (var key in cookies) {
    if (cookieName === key) {
      return true;
    }
  }
  return false;
}

function buttonClicked() {
  var gender;
  var name = document.getElementById("name").value;
  var age = document.getElementById("age").value;
  var male = document.getElementById("male").checked;
  var female = document.getElementById("female").checked;
  male ? (gender = "male") : null;
  female ? (gender = "female") : null;
  var index = document.getElementById("colors").selectedIndex;
  var color = document.getElementById("colors").options[index].value;
  var txt = document.getElementById("colors").options[index].text;
  var date = new Date();
  setCookie("visitCount", 0, date.getDate());
  date.setMonth(date.getMonth() + 3);
  setCookie("username", name, date);
  setCookie("agee", age, date);
  setCookie("genderr", gender, date);
  setCookie("collor", color, date);
  location.replace("child.html");
}

function displayInfo() {
  date = new Date();
  var count = getCookie("visitCount");
  count++;
  setCookie("visitCount", count, date.getDate());
  var gender = getCookie("genderr");
  var name = getCookie("username");
  var color = getCookie("collor");
  gender === "male"  ? (document.images[0].src = "img/1.jpg") : (document.images[0].src = "img/2.jpg");
  document.getElementById("data").innerHTML = "<span style='font:20px bold'>Welcome,</span><span  style=color:"+color+">"+name+"</span> you have visited this site <span style='color:"+ color+"'>"+count+"</span> times :)";
}
function check(){
  try{
    na = getCookie("username");
    console.log(na);
    if (na!="") {
      console.log("Welcome again "+getCookie("username"));
  
     } else{
       throw new Error('the value of cookie is empty');
     }
  }catch(e){
    
      console.error(e.message);
  
}

}
check();

